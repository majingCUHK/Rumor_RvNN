Distro - a Linux OS platform information API
============================================

See `Official GitHub repo <https://github.com/nir0s/distro#distro---a-linux-os-platform-information-api>`_.


